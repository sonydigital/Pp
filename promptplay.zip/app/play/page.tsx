import Link from "next/link";
import { ArrowRight, Rocket } from "lucide-react";
import { DEMO_GAME } from "../../lib/demo-game";

function decodeGame(value?: string) { if (!value) return DEMO_GAME; try { return Buffer.from(decodeURIComponent(value), "base64").toString("utf8") || DEMO_GAME; } catch { return DEMO_GAME; } }
export default function PlayPage({ searchParams }: { searchParams: { g?: string } }) { const code = decodeGame(searchParams.g); return <main className="play-page"><div className="play-top"><Link href="/" className="portal-brand"><span className="portal-logo"><Rocket size={20} /></span><span><b>PromptPlay</b><small>AI-академия для детей</small></span></Link><Link href="/academy" className="play-back">Создать свою игру <ArrowRight size={15} /></Link></div><iframe className="play-frame" title="Игра PromptPlay" sandbox="allow-scripts" srcDoc={code} /><div className="play-cta"><div><b>Создано в PromptPlay</b><span>Сделай свою игру бесплатно и научись управлять ИИ.</span></div><Link href="/academy">Попробовать бесплатно <ArrowRight size={16} /></Link></div></main>; }
