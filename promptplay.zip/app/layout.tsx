import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PromptPlay — студия AI-кодинга",
  description: "Игровая студия для обучения детей AI-промптингу и vibe-coding."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ru"><body>{children}</body></html>;
}
