import LegalPage from "../LegalPage";
export default function OfferPage() { return <LegalPage kind="offer" />; }
