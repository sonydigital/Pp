import LegalPage from "../LegalPage";
export default function ContactsPage() { return <LegalPage kind="contacts" />; }
