/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  allowedDevOrigins: ["127.0.0.1", "localhost", "*.manus.computer", "*.manus.im"]
};
export default nextConfig;
